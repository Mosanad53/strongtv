<?php
  get_header();
  ?>
<div class="alba-single">
  <?php while (have_posts()): the_post();?>
  <section class="box clearfix ">
    <h1 class="post-title"> <?php the_title();?></h1>
    <div id="entry">
      <div class="entry">
        <?php the_content();?>
      </div>
    </div>
  </section>
  <?php endwhile;?>
</div>
<?php
get_footer();