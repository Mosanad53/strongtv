<?php
   get_header();
   ?>
<div class="alba-single row justify-content-center">
   <div class="content-area col-12 <?php if(get_theme_mod('albasidebaron', '')){echo "col-lg-8 pr-lg-0";}?>">
      <?php while (have_posts()): the_post();?>
          <section class="main-content clearfix box">
            <div class="page-title">
                <h1 class="post-title"> <?php the_title();?></h1>
                <div class="conteneur_barre_outils">
                   <div class="bloc_signature">
                      <span class="time"><?php the_time('j F Y')?> - <?php the_time('g:i a');?></span>
                   </div>
                </div>
             </div>
             <?php if (has_post_thumbnail()) { ?><div class="featured-area"><?php the_post_thumbnail('bgslide-thumb');?> </div><?php } ?>

            <div class="content_entry">
               <?php the_content();?>
                <?php the_tags('<div class="post_tags">', ' ', '</div>');?>
                </div>
          </section>
          <section class="box clearfix ">
        <?php
            if (comments_open() || get_comments_number()):
             comments_template();
             endif;
         ?>
      </section>
      <?php endwhile;?>
      </div>
      <?php if(get_theme_mod('albasidebaron', '')){get_sidebar();}?>
</div>
<?php
get_footer();
