<?php
   get_header(); ?>
<div class="page-content alba-no-found box pb-5">
   <header class="404-header">
      <h1><?php _e('عفوا، لا يمكن إيجاد هاذه الصفحة.','alba');?></h1>
   </header>
   <p><?php _e('يبدو أنه لا يوجد أي شئ هنا. جرب أحد الروابط الموجودة في الأسفل أو استخدم أداة البحث.','alba');?></p>
   <div class="text_404">404</div>
   <?php query_posts( array(
      'posts_per_page' => 3,
      )); ?>
   <?php if( have_posts() ): ?>
   <h4><?php _e('أحدث المقالات','alba');?></h4>
   <ul>
      <?php while ( have_posts() ) : the_post(); ?>
      <li>
         <h2><a href="<?php the_permalink() ?>" title="<?php the_title();?>"><?php the_title(); ?></a></h2>
      </li>
      <?php endwhile; ?>
   </ul>
   <?php endif; ?>
</div>
<?php
get_footer();

