<?php if(get_theme_mod('AlbaHeaderAds') != ''){ ?>
      <div class="AspThemeAds mb-2">
            <?php echo get_theme_mod('AlbaFooterAds'); ?>
        </div>
        <?php } ?>
</div>
</div>
<footer id="colophon" class="alba-footer">
<div class="fwidgets">
<div class="container">
<div class="row">

<?php 
for ($i=1; $i < 5; $i++) { 
if (is_active_sidebar('footer_'.$i) ) {
  echo '<div class="fwd fwd'.$i.' col-lg-3 col-12">';
  dynamic_sidebar('footer_'.$i);
  echo '</div>';
}
}
?>
</div></div>
</div>





  <div class="site-info">
  <div class="container">

        <div class="row">
          <p class="footer_copyRights col-12 col-md-6 d-md-inline-flex"><?php _e('جميع الحقوق محفوظة ©','alba');?> <?php echo bloginfo('name');?></p>
          <div class="footer_creared col-12 col-md-6 d-md-inline-flex justify-content-end">
            <a href="https://www.albaadani.com/" rel="dofollow" target="_blank" title="Designed by | albaadani"> Designed by | albaadani</a>
          </div>
      </div>
  </div>
</footer>
<script async>
function toggleClass(el,className){var el=document.querySelectorAll(el);for(i=0;i<el.length;i++){if(el[i].classList){el[i].classList.toggle(className);}else{var classes=el[i].className.split(' ');var existingIndex=-1;for(var j=classes.length;j--;){if(classes[j]===className)
existingIndex=j;}
if(existingIndex>=0)
classes.splice(existingIndex,1);else
classes.push(className);el[i].className=classes.join(' ');}}}
</script>
<?php wp_footer(); ?>
</body>
</html>
