<?php
  get_header();
  ?>
<div class="alba-archive row">
  <div id="primary" class="content-area  col-md-8 col-sm-12 pr-0">
    <main id="main" class="site-main box">
      <?php if ( have_posts() ) : ?>
        <div class="box-title">
        <?php the_archive_title( '<h1 class="title">', '</h1>' );?>
        </div>
        <?php the_archive_description( '<div class="taxonomy-description">', '</div>' );?>
      <div class="polist row c3l">
        <?php while (have_posts()): the_post();?>
        <article id="post-<?php the_ID();?>" class="post_outer col-sm-6 col-12 col-md-4">
          <a class="d-flex flex-column flex-grow post-link" href="<?php the_permalink()?>" title="<?php the_title();?>">
            <div class="inner-content">
              <div class="thumbnail">
                <div class="thumb-wrap" style="background-image: url('<?php the_post_thumbnail_url('medium');?>');"></div>
              </div>
              <span class="overlay"></span>
              <h3 class="main-color-border">
                <div class="title-inner">
                  <?php the_title();?>
                </div>
              </h3>
            </div>
          </a>
        </article>
        <?php endwhile;?>
      </div>
      <?php
        if (function_exists("AlbaSport_pagination")) { AlbaSport_pagination(); } ;
        else :
        ?>
      <section class="no-results not-found">
        <header class="page-header">
          <h1 class="page-title"><?php _e( 'لا يوجد شي ','alba'); ?></h1>
        </header>
      </section>
      <?php
        endif;
        ?>
    </main>
  </div>
  <?php get_sidebar(); ?>
</div>
<?php
get_footer();