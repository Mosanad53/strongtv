<?php
  get_header();
  ?>
<div class="alba-archive row">
  <section id="primary" class="content-area col">
    <main id="main" class="site-main box">
      <?php if ( have_posts() ) : ?>
      <h1 class="pasge-title mb-2">
        <?php
          printf( esc_html__( 'نتائج البحث عن: %s','alba'), '<span>' . get_search_query() . '</span>' );
          ?>
      </h1>
      <div class="polist row c3l">
        <?php
          /* Start the Loop */
          while ( have_posts() ) :
          	the_post();?>
        <article id="post-<?php the_ID();?>" class="post_outer">
          <a class="d-flex flex-column flex-grow post-link" href="<?php the_permalink()?>" title="<?php the_title();?>">
            <div class="inner-content">
              <div class="thumbnail">
                <div class="thumb-wrap" style="background-image: url('<?php the_post_thumbnail_url('medium');?>');"></div>
              </div>
              <span class="overlay"></span>
              <h3 class="main-color-border">
                <div class="title-inner">
                  <?php the_title();?>
                </div>
              </h3>
            </div>
          </a>
        </article>
        <?php	endwhile;
          if (function_exists("AlbaSport_pagination")) { AlbaSport_pagination(); } ;
          
          else :
          
          get_template_part( 'content', 'none' );
          
          endif;
          ?>
      </div>
    </main>
  </section>
</div>
<?php
get_footer();