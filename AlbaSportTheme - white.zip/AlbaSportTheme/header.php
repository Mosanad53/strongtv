<!DOCTYPE html>
<html <?php language_attributes(); ?>>
   <head>
      <meta charset="<?php bloginfo( 'charset' ); ?>">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="profile" href="https://gmpg.org/xfn/11">
      <?php wp_head(); ?>
   </head>
   <?php $bdclss = is_rtl() ? 'Alba-rtl' : 'Alba-ltr';?>
   <body <?php body_class($bdclss); ?>>

      
      <header id="AlbaSport_header">
         <div class="container">
            <div class="header_inn d-flex align-items-center">
               <div class="alba-logo mr-4 d-inline-flex align-items-center">
                  <?php if( function_exists( 'the_custom_logo' ) ) {
                     if(has_custom_logo()) {
                        the_custom_logo();
                     } else { ?>
                  <a href="<?php echo home_url();?>" rel="home" class="custom-logo-link  d-inline-flex align-items-center">
                  <img src="<?php echo get_template_directory_uri();?>/img/logo.png" class="custom-logo" alt="<?php echo bloginfo('name');?>" width="200" height="54">
                  </a> 
                  <?php                     
                     }
                     }
                     ?>
               </div>
               <nav id="site-navigation" class="AlbaSport_menu d-flex justify-content-end flex-fill">
                  <span class="fa fa-close" id="menu-close" onclick="toggleClass('#site-navigation', 'open')"></span>
                  <div id="mainmenu" class="menu-header-container">
                  <?php
                     wp_nav_menu( array(
                     	'theme_location' => 'header',
                     	'menu_id'        => 'primary-menu',
                     	'container' => false
                     ) );
                     ?>
                     <?php AlbaSocial();?>
                  </div>
               </nav>
               <button class="navbar-toggler ml-0 order-lg-3" onclick="toggleClass('#site-navigation', 'open')" type="button" id="toggle-menu">
               <span class="navbar-toggler-icon"><i class="mobmnicon"></i></span>
               </button>
            </div>
         </div>
      </header>
      <div id="content" class="container">
      <div class="wrapper clearfix mb-4">
      <?php if(get_theme_mod('AlbaHeaderAds') != ''){ ?>
      <div class="AspThemeAds mb-2">
         <?php echo get_theme_mod('AlbaHeaderAds'); ?>
      </div>
      <?php } ?>