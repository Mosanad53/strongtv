<article id="post-<?php the_ID();?>" class="post_outer col-sm-6 col-12 col-md-3">
    <a class="d-flex flex-column flex-grow post-link" href="<?php the_permalink()?>" title="<?php the_title();?>">
    <div class="inner-content">
        <div class="thumbnail">
            <div class="thumb-wrap" style="background-image: url('<?php the_post_thumbnail_url('medium');?>');"></div>
        </div>
        <span class="overlay"></span>
        <h3 class="main-color-border">
            <div class="title-inner">
                <?php the_title();?>
            </div>
        </h3>
    </div>
    </a>
</article>