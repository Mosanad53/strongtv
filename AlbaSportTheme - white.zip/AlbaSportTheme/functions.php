<?php
if ( ! function_exists( '' ) ) :
  function alba_setup() {
    remove_action('wp_head', 'rsd_link');
    remove_action('wp_head', 'wp_generator');
    remove_action('wp_head', 'feed_links', 2);
    remove_action('wp_head', 'feed_links_extra', 3);
    remove_action('wp_head', 'index_rel_link');
    remove_action('wp_head', 'wlwmanifest_link');
    remove_action('wp_head', 'start_post_rel_link', 10, 0);
    remove_action('wp_head', 'parent_post_rel_link', 10, 0);
    remove_action('wp_head', 'adjacent_posts_rel_link', 10, 0);
    remove_action('wp_head', 'adjacent_posts_rel_link_wp_head', 10, 0);
    remove_action('wp_head', 'wp_shortlink_wp_head', 10, 0);
    remove_action('wp_head', 'print_emoji_detection_script', 7);
    remove_action('wp_head', 'rel_canonical');
    remove_action('wp_head', 'rel_alternate');
    remove_action('wp_head', 'wp_oembed_add_discovery_links');
    remove_action('wp_head', 'wp_oembed_add_host_js');
    remove_action('wp_head', 'rest_output_link_wp_head');
    remove_action('rest_api_init', 'wp_oembed_register_route');
    remove_action('wp_print_styles', 'print_emoji_styles');
    remove_filter('oembed_dataparse', 'wp_filter_oembed_result', 10);
    remove_filter('pre_oembed_result', 'wp_filter_pre_oembed_result', 10);
    add_filter('embed_oembed_discover', '__return_false');
    remove_theme_support('widgets-block-editor');
  }
endif;
add_action( 'after_setup_theme', 'alba_setup' );
add_filter( 'wpcf7_load_js', '__return_false' );
add_filter( 'wpcf7_load_css', '__return_false' );

if ( ! function_exists( 'AlbaSport_setup' ) ) :
  function AlbaSport_setup() {
    load_theme_textdomain('alba', get_template_directory().'/lang');
    add_theme_support( 'automatic-feed-links' );
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_image_size( 'homepage-thumb', 382, 430, true );   
    add_image_size( 'bgslide-thumb', 773, 435, true ); 
    add_image_size( 'cpost-thumb', 400, 225, true ); 
    register_nav_menus( array(
      'header' => esc_html__( 'Header'),
    ) );
    add_theme_support( 'html5', array(
      'search-form',
      'comment-form',
      'comment-list',
      'gallery',
      'caption',
    ) );

    add_theme_support( 'customize-selective-refresh-widgets' );
    add_theme_support( 'custom-logo', array(
      'height'      => 220,
      'width'       => 60,
      'flex-width'  => true,
      'flex-height' => true,
    ) );

  }
endif;
add_action( 'after_setup_theme', 'AlbaSport_setup' );
function wps_deregister_styles() {
  wp_dequeue_style('wp-block-library');
  wp_dequeue_style('wp-block-library-theme');
  wp_dequeue_style('wc-blocks-style'); // Remove WooCommerce block CSS
  wp_dequeue_style('global-styles');
  wp_deregister_script( 'toc-front');
  wp_dequeue_style( 'toc-screen');
  wp_deregister_style( 'toc-screen');
  wp_dequeue_style( 'global-styles' );
}
add_action( 'wp_enqueue_scripts', 'wps_deregister_styles', 100 );
/*-----------------------------------------------------------------------------------*/
# widgets
/*-----------------------------------------------------------------------------------*/
function AlbaSport_widgets_init() {
  register_sidebar( array(
    'name'          => esc_html__( '#الصفحة الرئيسية فوق جدول المباريات','alba'),
    'id'            => 'home_widget_top',
    'description'   => esc_html__( ''),
    'before_widget' => '<div id="%1$s" class="widget box %2$s">',
    'after_widget'  => '</div>',
    'before_title'  => '<div class="box-title"><h2 class="title">',
    'after_title'   => '</h2></div>',
  ) );
  register_sidebar( array(
    'name'          => esc_html__( '#الصفحة الرئيسية اسفل جدول المباريات','alba'),
    'id'            => 'home_widget',
    'description'   => esc_html__( ''),
    'before_widget' => '<div id="%1$s" class="widget box %2$s">',
    'after_widget'  => '</div>',
    'before_title'  => '<div class="box-title"><h2 class="title">',
    'after_title'   => '</h2></div>',
  ) );
  register_sidebar( array(
    'name'          => esc_html__( '#السايدبار','alba'),
    'id'            => 'sidebar',
    'description'   => esc_html__( ''),
    'before_widget' => '<div id="%1$s" class="widget box %2$s">',
    'after_widget'  => '</div>',
    'before_title'  => '<div class="box-title"><h4 class="title">',
    'after_title'   => '</h4></div>',
  ) );

for ($i=1; $i < 5; $i++) { 
  register_sidebar( array(
    'name'          => esc_html__( '# فوتر '.$i,'alba'),
    'id'            => 'footer_'.$i,
    'before_widget' => '<div class="widget %2$s">',
    'after_widget'  => '</div>',
    'before_title'  => '<div class="fwd-title"><h4 class="title">',
    'after_title'   => '</h4></div>',
  ) );
}

}
add_action( 'widgets_init', 'AlbaSport_widgets_init' );

function AlbaSport_scripts() {
  wp_enqueue_style( 'theme-styles', get_stylesheet_uri() ,array(),'3.0'); 
  if(!is_rtl()){
  wp_enqueue_style( 'Roboto-font', 'https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap' ,array(),'1.0'); 
  }
  wp_deregister_script( 'jquery' );
  wp_enqueue_script( 'jquery', 'https://code.jquery.com/jquery-3.3.1.min.js', false, null , true );
  if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
    wp_enqueue_script( 'comment-reply' );
  }
}
add_action( 'wp_enqueue_scripts', 'AlbaSport_scripts' );
function Alba_rtl_font() {
  if(!is_rtl()){return;}
  if(in_array('AlbaSport/albasport.php', apply_filters('active_plugins', get_option('active_plugins')))){ return;}
?>
<style>
@font-face{font-family:'Droid Arabic Kufi';font-style:normal;font-weight:400;src:url(//fonts.gstatic.com/ea/droidarabickufi/v6/DroidKufi-Regular.eot);src:url(//fonts.gstatic.com/ea/droidarabickufi/v6/DroidKufi-Regular.eot?#iefix) format("embedded-opentype"),url(//fonts.gstatic.com/ea/droidarabickufi/v6/DroidKufi-Regular.woff2) format("woff2"),url(//fonts.gstatic.com/ea/droidarabickufi/v6/DroidKufi-Regular.woff) format("woff"),url(//fonts.gstatic.com/ea/droidarabickufi/v6/DroidKufi-Regular.ttf) format("truetype")}
@font-face{font-family:'Droid Arabic Kufi';font-style:normal;font-weight:700;src:url(//fonts.gstatic.com/ea/droidarabickufi/v6/DroidKufi-Bold.eot);src:url(//fonts.gstatic.com/ea/droidarabickufi/v6/DroidKufi-Bold.eot?#iefix) format("embedded-opentype"),url(//fonts.gstatic.com/ea/droidarabickufi/v6/DroidKufi-Bold.woff2) format("woff2"),url(//fonts.gstatic.com/ea/droidarabickufi/v6/DroidKufi-Bold.woff) format("woff"),url(//fonts.gstatic.com/ea/droidarabickufi/v6/DroidKufi-Bold.ttf) format("truetype")}
</style>
<?php 
}
add_action( 'wp_head', 'Alba_rtl_font',100 );

add_filter( 'get_the_archive_title', function ($title) {
    if ( is_category() || is_tax( 'leagues' )) {
            $title = single_cat_title( '', false );
        }  elseif ( is_author() ) {

            $title = '<span class="vcard">' . get_the_author() . '</span>' ;

        }
    return $title;
});
require get_template_directory() . '/inc/AlbaPosts.php';
require get_template_directory() . '/inc/AlbaOptions.php';
function AlbaSport_pagination( $args = array() ) {
    
    $defaults = array(
        'range'           => 3,
        'custom_query'    => FALSE,
        'previous_string' => __( 'السابق','alba'),
        'next_string'     => __( 'التالي','alba'),
        'before_output'   => '<div class="pagination-centered"><ul class="pager">',
        'after_output'    => '</ul></div>'
        );
    
    $args = wp_parse_args( 
        $args, 
        apply_filters( 'AlbaSport_pagination_defaults', $defaults )
        );
    
    $args['range'] = (int) $args['range'] - 1;
    if ( !$args['custom_query'] )
        $args['custom_query'] = @$GLOBALS['wp_query'];
    $count = (int) $args['custom_query']->max_num_pages;
    $page  = intval( get_query_var( 'paged' ) );
    $ceil  = ceil( $args['range'] / 2 );
    
    if ( $count <= 1 )
        return FALSE;
    
    if ( !$page )
        $page = 1;
    
    if ( $count > $args['range'] ) {
        if ( $page <= $args['range'] ) {
            $min = 1;
            $max = $args['range'] + 1;
        } elseif ( $page >= ($count - $ceil) ) {
            $min = $count - $args['range'];
            $max = $count;
        } elseif ( $page >= $args['range'] && $page < ($count - $ceil) ) {
            $min = $page - $ceil;
            $max = $page + $ceil;
        }
    } else {
        $min = 1;
        $max = $count;
    }
    
    $echo = '';
    $previous = intval($page) - 1;
    $previous = esc_attr( get_pagenum_link($previous) );
    
    $firstpage = esc_attr( get_pagenum_link(1) );
    if ( $firstpage && (1 != $page) )
        $echo .= '<li class="previous"><a href="' . $firstpage . '">' . __( 'الصفحة الاولى','alba') . '</a></li>';
    if ( $previous && (1 != $page) )
        $echo .= '<li><a href="' . $previous . '" title="' . __( 'السابق','alba') . '">' . $args['previous_string'] . '</a></li>';
    
    if ( !empty($min) && !empty($max) ) {
        for( $i = $min; $i <= $max; $i++ ) {
            if ($page == $i) {
                $echo .= '<li class="active"><span class="active">' . str_pad( (int)$i, 2, '0', STR_PAD_LEFT ) . '</span></li>';
            } else {
                $echo .= sprintf( '<li><a href="%s">%002d</a></li>', esc_attr( get_pagenum_link($i) ), $i );
            }
        }
    }
    
    $next = intval($page) + 1;
    $next = esc_attr( get_pagenum_link($next) );
    if ($next && ($count != $page) )
        $echo .= '<li><a href="' . $next . '" title="' . __( 'التالي','alba') . '">' . $args['next_string'] . '</a></li>';
    
    $lastpage = esc_attr( get_pagenum_link($count) );
    if ( $lastpage ) {
        $echo .= '<li class="next"><a href="' . $lastpage . '">' . __( 'الصحفة الاخيرة','alba') . '</a></li>';
    }
    if ( isset($echo) )
        echo $args['before_output'] . $echo . $args['after_output'];
}