<?php get_header(); ?>
<?php dynamic_sidebar( 'home_widget_top' ); ?>
<?php 
if(in_array('AlbaSport/albasport.php', apply_filters('active_plugins', get_option('active_plugins')))){
  echo do_shortcode('[AlbaSportTable]'); 
}
?>
<?php dynamic_sidebar( 'home_widget' ); ?>
<?php if (have_posts()): ?>
<main id="main" class="AlbaSport-main box">
   <div class="box-title">
      <h2 class="title"><?php echo __('اخر الاخبار','alba');?></h2>
   </div>
   <div class="polist row">
      <?php 
      while (have_posts()): the_post();
         get_template_part( 'content');
      endwhile;
      ?>
   </div>
   <?php if (function_exists("AlbaSport_pagination")) {AlbaSport_pagination();}?>
</main>
<?php endif;?>
<?php get_footer();