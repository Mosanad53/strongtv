<?php
  get_header();
  ?>
<div class="alba-single">
  <?php while (have_posts()): the_post();?>
  <section class="main-content clearfix box">
  <div class="page-title"><h1 class="post-title"> <?php the_title();?></h1></div>
    <div id="entry">
      <div class="content_entry">
        <?php the_content();?>
      </div>
    </div>
  </section>
  <?php endwhile;?>
</div>
<?php
get_footer();