<?php
  if ( ! is_active_sidebar( 'sidebar' ) ) {return;}?>
<aside id="sidebar" class="sidebar col-lg-4 col-12">
  <?php dynamic_sidebar( 'sidebar' ); ?>
</aside>
