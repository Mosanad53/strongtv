<div class='col-12 col-md-4'>
<a class="post-item d-flex" href="<?php the_permalink()?>" title="<?php the_title();?>">
    <div class="thumbnail">
        <div class="thumb-wrap" style="background-image: url('<?php the_post_thumbnail_url('medium');?>');"></div>
    </div>
    <h3 class="main-color-border">
        <div class="title-inner"><?php the_title();?></div>
    </h3>
</a>
</div>