<?php

if ( ! function_exists( 'register_AlbaSport_news_widget' ) ) {
function register_AlbaSport_news_widget() { 
register_widget( 'AlbaSport_news_widget' );
}
}
add_action( 'widgets_init', 'register_AlbaSport_news_widget' );
class AlbaSport_news_widget extends WP_Widget {
/*  Constructor
------------------------------------ */
function __construct() {
parent::__construct('AlbaSport_news_widget', __('AlbaSport | قائمة المقالات'), array( 'description' => __( 'عرض المواضيع على شكل مربعات' ), ) );
}
/*  Widget
------------------------------------ */
public function widget($args, $instance) {
extract( $args );
$Hidon         = $instance['Hidon'];
$title         = $instance['title'];
$widget_style  = $instance['widget_style'];
$cat = $instance['posts_cat_id'];
$pagenumber = $instance[ 'pagenumber' ];
if(wp_is_mobile()){ if($Hidon == 'mobile'){return ;}}else{if($Hidon == 'comp'){return ;}}
if(wp_is_mobile()){
   $showposts = $instance['posts_num_mob'];
}else{
   $showposts = $instance['posts_num'];
}
$invite = implode(",", (array)$cat);
$paged = ( get_query_var('paged') > 1 ) ? get_query_var('paged') : 1;
$post_arrgs = array(
'posts_per_page'		=> $showposts,
'post_status'           => 'publish',
'cat'					=> $invite,
'ignore_sticky_posts'	=> true,
'orderby'				=> $instance['posts_orderby'],
'order'					=> 'DESC',
'date_query' => array(
array(
'after' => $instance['posts_time'],
),
),
'paged' =>  $paged
) ;
$posts = new WP_Query($post_arrgs);
$drcls =  $widget_style;
$con = 0;
$title = apply_filters('widget_title', empty($instance['title']) ? '' : $instance['title'] , $instance, $this->id_base);
echo $before_widget;
if ( $title ) { echo $before_title.$title.$after_title;}   

echo '<div class="polist row '.$drcls.'">';
while ($posts->have_posts()): $posts->the_post();$con++;
if($widget_style == 's2' || $widget_style == 's3'){
    get_template_part( 'content','s2');
}elseif($widget_style == 's4'){
?>
<div class='col-12'><a class="post-item d-flex" href="<?php the_permalink()?>" title="<?php the_title();?>"><h3 class="title-inner"><?php the_title();?></h3></a></div>
<?php
}else{
    get_template_part( 'content');

}
endwhile;
wp_reset_postdata();
echo '</div>';

echo $after_widget;

}
public function update($new,$old) {
$instance = $old;
$instance['title'] = strip_tags($new['title']);
// Posts
$instance['widget_style'] = strip_tags( $new['widget_style'] );       
$instance['posts_num'] = $new['posts_num'];
$instance['posts_num_mob'] = $new['posts_num_mob'];
$instance['posts_cat_id'] = $new['posts_cat_id'];
$instance['pagenumber'] = $new['pagenumber'];
$instance['posts_orderby'] = strip_tags($new['posts_orderby']);
$instance['posts_time'] = strip_tags($new['posts_time']);
$instance['Hidon'] = strip_tags($new['Hidon']);
return $instance;
}
public function form($instance) {
$defaults = array(
'title' 			=> ' أحدث المقالات',
'posts_num' 		=> 8,
'posts_num_mob' 		=> 8,
'posts_cat_id' 		=> 1,
'pagenumber' 		=> '0',
'posts_orderby'     => 'date',
'posts_time' 		=> '0',
'Hidon' 		    => '0',
'widget_style'      => 's1',
);
$instance = wp_parse_args( (array) $instance, $defaults );
$widget_style = $instance['widget_style'];
?>
<style>/*<![CDATA[*/.widget .widget-inside .postslist-options .postform{width:100%}.widget .widget-inside .postslist-options p{margin:3px 0}.widget .widget-inside .postslist-options hr{margin:20px 0 10px}.widget .widget-inside .postslist-options h4{margin-bottom:10px}/*]]>*/</style>
<p>
<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('عنوان: ');?></label>
<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo esc_attr($instance["title"]); ?>" />
</p>

   <p>
   <div style="display: flex;overflow: hidden;width: 100%;clear: both;border: solid 1px #fff;padding: 10px;box-sizing: border-box;background: #eee;">
         <?php _e('عدد المقالات');?>
      </div>
      <div style="display: flex;overflow: hidden;width: 100%;clear: both;border: solid 1px #fff;padding: 10px;box-sizing: border-box;background: #eee;">
         <div style="display: flex;flex-direction: column;border-left: 1px #fff solid;padding-left: 10px;flex: 0 0 50%;box-sizing: border-box;">
            <label><?php _e('كمبيوتر');?></label>
            <input id="<?php echo $this->get_field_id("posts_num"); ?>" style="width: 100px;" name="<?php echo $this->get_field_name("posts_num"); ?>" type="number" value="<?php echo absint($instance["posts_num"]); ?>" size='3' />
         </div>
         <div style="justify-content: center;display: flex;flex-direction: column;flex: 0 0 50%;padding-right: 10px;box-sizing: border-box;">
            <label><?php _e('جوال');?></label>
            <input id="<?php echo $this->get_field_id("posts_num_mob"); ?>" style="width: 100px;" name="<?php echo $this->get_field_name("posts_num"); ?>" type="number" value="<?php echo absint($instance["posts_num_mob"]); ?>" size='3' />
         </div>
      </div>
   </p>
   <div class="postslist-options">
   <p>
      <div style="display: flex;overflow: hidden;width: 100%;clear: both;border: solid 1px #fff;padding: 10px;box-sizing: border-box;background: #eee;flex-direction: column;">
               <div id="<?php echo $this->get_field_id("posts_cat_id"); ?>" class="<?php echo $this->get_field_id("posts_cat_id"); ?>">
                  <label for="<?php echo $this->get_field_id("posts_cat_id"); ?>"><?php _e('التصنيفات');?></label>
                  <div class="multicheck-option" style="max-width: 360px;max-height: 140px;overflow-x: auto;border: solid 2px #CAD0D9;padding: 10px;background: #fff;">
                     <?php
                        $categories=  get_categories();
                        foreach ($categories as $cat) {
                        $option='<input type="checkbox" id="'. $this->get_field_id( 'posts_cat_id' ) .'[]" name="'. $this->get_field_name( 'posts_cat_id' ) .'[]"';
                        if (is_array($instance['posts_cat_id'])) {
                        foreach ($instance['posts_cat_id'] as $cats) {
                        if($cats==$cat->term_id) {
                        $option=$option.' checked="checked"';
                        }
                        }
                        }
                        $option .= ' value="'.$cat->term_id.'" />';
                                          $option .= $cat->cat_name;
                                          $option .= ' ('.$cat->category_count.')';
                                          $option .= '<br />';
                                          echo $option;
                                          }
                                          ?>
                  </div>
               </div>
            </div>
   </p>
   <p>
      <div>
         <ul id="single_post" class="box_tabs_container">
            <li>
            <label for="<?php echo $this->get_field_id('widget_style'); ?>s1">
            <input type="radio" id="<?php echo $this->get_field_id('widget_style'); ?>s1" name="<?php echo $this->get_field_name('widget_style'); ?>" <?php if($widget_style === 's1'){ echo 'checked="checked"'; } ?> value="s1"/>
            <img class="lazy" style="transform: scaleX(-1);max-width: 150px;" src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/s1.png" alt="<?php echo $this->get_field_id('widget_style'); ?>s1"/>
            </label>
            </li>
            <li>
            <label for="<?php echo $this->get_field_id('widget_style'); ?>s2">
            <input id="<?php echo $this->get_field_id('widget_style'); ?>s2" type="radio" name="<?php echo $this->get_field_name('widget_style'); ?>" <?php if($widget_style === 's2'){ echo 'checked="checked"'; } ?> value="s2"/>
            <img class="lazy" style="transform: scaleX(-1);max-width: 150px;" src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/s2.png" alt="<?php echo $this->get_field_id('widget_style'); ?>s2"/>
            </label>
            </li>
            <li>
            <label for="<?php echo $this->get_field_id('widget_style'); ?>s3">
            <input id="<?php echo $this->get_field_id('widget_style'); ?>s3" type="radio" name="<?php echo $this->get_field_name('widget_style'); ?>" <?php if($widget_style === 's3'){ echo 'checked="checked"'; } ?> value="s3"/>
            <img class="lazy" style="transform: scaleX(-1);max-width: 150px;" src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/s3.png" alt="<?php echo $this->get_field_id('widget_style'); ?>s3"/>
            </label>
            </li>

            <li>
            <label for="<?php echo $this->get_field_id('widget_style'); ?>s4">
            <input id="<?php echo $this->get_field_id('widget_style'); ?>s4" type="radio" name="<?php echo $this->get_field_name('widget_style'); ?>" <?php if($widget_style === 's4'){ echo 'checked="checked"'; } ?> value="s4"/>
            <img class="lazy" style="transform: scaleX(-1);max-width: 150px;" src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/s4.png" alt="<?php echo $this->get_field_id('widget_style'); ?>s4"/>
            </label>
            </li>


         </ul>
      </div>
   </p>

  <p> 
  <div style="display: flex;overflow: hidden;width: 100%;clear: both;border: solid 1px #fff;padding: 10px;box-sizing: border-box;background: #eee;">
            <div style="display: flex;flex-direction: column;border-left: 1px #fff solid;padding-left: 10px;flex: 0 0 50%;box-sizing: border-box;">
               <label style="width:100%;display:inline-block" for="<?php echo $this->get_field_id("posts_orderby"); ?>">
               <?php _e('ترتيب حسب :');?>
               </label>
               <select style="width:100%" id="<?php echo $this->get_field_id("posts_orderby"); ?>" name="<?php echo $this->get_field_name("posts_orderby"); ?>">
                  <option value="date" <?php selected( $instance["posts_orderby"], "date" ); ?>>
                     <?php _e('الأحدث');?>
                  </option>
                  <option value="meta_value_num" <?php selected( $instance["posts_orderby"], "meta_value_num" ); ?>>
                     <?php _e('الاكثر مشاهدة');?>
                  </option>
                  <option value="comment_count" <?php selected( $instance["posts_orderby"], "comment_count" ); ?>>
                     <?php _e('الأكثر تعليقا');?>
                  </option>
                  <option value="rand" <?php selected( $instance["posts_orderby"], "rand" ); ?>>
                     <?php _e('عشوائي');?>
                  </option>
               </select>
            </div>
            <div style="justify-content: center;display: flex;flex-direction: column;flex: 0 0 50%;padding-right: 10px;box-sizing: border-box;">
               <label style="width:100%;display:inline-block" for="<?php echo $this->get_field_id("posts_time"); ?>">
               <?php _e('المقالات من');?>
               </label>
               <select style="width:100%" id="<?php echo $this->get_field_id("posts_time"); ?>" name="<?php echo $this->get_field_name("posts_time"); ?>">
                  <option value="0" <?php selected( $instance["posts_time"], "0" ); ?>>All time
                  </option>
                  <option value="1 year ago" <?php selected( $instance["posts_time"], "1 year ago" ); ?>>
                     <?php _e('هذا العام');?>
                  </option>
                  <option value="1 month ago" <?php selected( $instance["posts_time"], "1 month ago" ); ?>>
                     <?php _e('هذا الشهر');?>
                  </option>
                  <option value="1 week ago" <?php selected( $instance["posts_time"], "1 week ago" ); ?>>
                     <?php _e('هذا الاسبوع');?>
                  </option>
                  <option value="1 day ago" <?php selected( $instance["posts_time"], "1 day ago" ); ?>>
                     <?php _e('24 ساعة الماضية');?>
                  </option>
               </select>
            </div>
         </div>
         <div style="display: flex;overflow: hidden;width: 100%;clear: both;border: solid 1px #fff;padding: 10px;box-sizing: border-box;background: #eee;">
            <div style="display: flex;flex-direction: column;flex:0 0 100%;box-sizing: border-box;">
               <label style="width:100%;display:inline-block" for="<?php echo $this->get_field_id("Hidon"); ?>">
               إخفاء على 
               </label>
               <select style="width:100%" id="<?php echo $this->get_field_id("Hidon"); ?>" name="<?php echo $this->get_field_name("Hidon"); ?>">
                  <option value="0" <?php selected( $instance["Hidon"], "0" ); ?>>-------</option>
                  <option value="mobile" <?php selected( $instance["Hidon"], "mobile" ); ?>>الجوال</option>
                  <option value="comp" <?php selected( $instance["Hidon"], "comp" ); ?>>الكمبيوتر</option>
               </select>
            </div>
         </div>
         <hr>
</p>
<style type="text/css">#single_post [type="radio"]:checked + img{border-color:#0073aa}#single_post *{box-sizing:border-box}#single_post{text-align:center;box-sizing:border-box;width:100%;max-width:100%;margin:0;padding:0;display:flex;flex-wrap:wrap}#single_post li{display:inline-block;width:50%!important;padding:5px!important;line-height:1!important}#single_post [type="radio"]{display:none!important;text-align:center;margin:0 auto 5px}#single_post label span{margin:0 1.333333px;border:#fff 3px solid;padding:2px;display:block}#single_post label span:hover{border-color:#d3d3d3}#single_post [type='radio']:checked+label span{border:3px solid #1050b1}#single_post label img{margin:0;border:#ececec 3px solid;padding:0;display:block}#single_post label img:hover{border-color:#d3d3d3}#single_post [type='radio']:checked+label img{border:3px solid #1050b1}.option-item{clear:both;padding:10px 0;overflow:hidden;display:block}span.labe2{width:115px;display:inline-block;float:right;padding-top:4px;font-weight:bold}</style>
</div>
<?php
}
}