<?php

function AkbaSport_get_customizer_css()
{
    ob_start();
    $background_color = get_theme_mod('background_color', '');
    $header_bd = get_theme_mod('header_bd', '');
    $header_color = get_theme_mod('header_color', '');
    $footer_bd = get_theme_mod('footer_bd', '');
    $footer_color = get_theme_mod('footer_color', '');

    if(get_theme_mod('albahsocial')){ ?>
    #hdsocial{display:flex;align-items:center;float:left;height:50px}#hdsocial a{height:35px;width:35px;padding:0;display:grid;background:#474747;margin-right:5px;border-radius:8px;float:left;cursor:pointer;line-height:35px!important;color:#fff;text-align:center;justify-content:center}@media only screen and (min-width:769px){#mainmenu{align-items:center;width:100%}#primary-menu{float:right}}#hdsocial svg{width:20px;height:20px}@media only screen and (max-width:768px){#hdsocial{width:100%;margin-top:12px;border:0}#hdsocial li{border:0}}#hdsocial .telegram a{background:#389ce9}#hdsocial .twitter a{background:#55acee}#hdsocial .facebook a{background:#4267b2}#hdsocial .whatsapp a{background:#47e363}#hdsocial .youtube a{background:#ff0000}
    <?php
    }
    if (!empty($background_color)) {
        ?>body{background: #<?php echo $background_color; ?>;}<?php
    }
    if (!empty($header_bd)) {
        ?>
        #AlbaSport_header{background-color: <?php echo $header_bd; ?>;}
        .AlbaSport_menu a{color: <?php echo $header_color; ?>;}
        .navbar-toggler-icon i::before, .navbar-toggler-icon i::after,.navbar-toggler-icon i{background-color: <?php echo $header_color; ?>;}
        .alba-footer ,.alba-footer a{background: <?php echo $footer_bd; ?>;color: <?php echo $footer_color; ?>;}
        <?php
    }
    $css = ob_get_clean();
    return $css;
}

// Modify our styles registration like so:

function AkbaSport_enqueue_styles()
{
    $custom_css = AkbaSport_get_customizer_css();
    wp_add_inline_style('theme-styles', $custom_css);
}

add_action('wp_enqueue_scripts', 'AkbaSport_enqueue_styles');

add_action('customize_register', 'AkbaSport_register_theme_customizer');
/*
 * Register Our Customizer Stuff Here
 */
function AkbaSport_register_theme_customizer($wp_customize)
{

    $wp_customize->add_panel('albasporthemeoption', array(
        'title'    => __('أعدادات قالب AlbaSportTheme', 'alba'),
        'priority'    => 20,
        'description' => '',
    ));
    


    $wp_customize->add_section('aspgenraloption', array(
        'title'    => __('اعدادات عامة', 'alba'),
        'priority'    => 1,
        'panel' => 'albasporthemeoption',
        'description' => '',
    ));

    $wp_customize->add_setting('albahsocial', array(
        'default'        => true,
        'sanitize_callback' => 'alba_theme_sanitize_checkbox'
    ));
  

    $wp_customize->add_control( 'albahsocial',
        array(
            'section'   => 'aspgenraloption',
            'label'      => __('إظهار ازرار مواقع التواصل', 'alba'),
            'type'      => 'checkbox'
        )
    );
    


//  =============================
//  = Text Input                =
//  =============================
$wp_customize->add_setting('albatelegram', array(
    'default'        => '#',
    'sanitize_callback' => 'sanitize_text_field',
    'capability' => 'edit_theme_options',  
));

$wp_customize->add_control('albatelegram', array(
    'label'      => __('telegram url'),
    'section' => 'aspgenraloption',
    'type'           => 'text',
));



 //  =============================
//  = Text Input                =
//  =============================
$wp_customize->add_setting('albafacebook', array(
    'default'        => '#',
    'sanitize_callback' => 'sanitize_text_field',
    'capability' => 'edit_theme_options',  

));

$wp_customize->add_control('albafacebook', array(
    'label'      => __('facebook url'),
    'section' => 'aspgenraloption',
    'type' => 'text',

));


 //  =============================
//  = Text Input                =
//  =============================
$wp_customize->add_setting('albayotube', array(
    'default'        => '#',
    'sanitize_callback' => 'sanitize_text_field',
    'capability' => 'edit_theme_options',  

));

$wp_customize->add_control('albayotube', array(
    'label'      => __('yotube url'),
    'section' => 'aspgenraloption',
    'type' => 'text',

));



 //  =============================
//  = Text Input                =
//  =============================
$wp_customize->add_setting('albatwitter', array(
    'default'        => '#',
    'sanitize_callback' => 'sanitize_text_field',
    'capability' => 'edit_theme_options',  

));

$wp_customize->add_control('albatwitter', array(
    'label'      => __('twitter url'),
    'section' => 'aspgenraloption',
    'type' => 'text',
));


$wp_customize->add_setting('albasidebaron', array(
    'default'        => true,
    'sanitize_callback' => 'alba_theme_sanitize_checkbox'
));


$wp_customize->add_control( 'albasidebaron',
    array(
        'section'   => 'aspgenraloption',
        'label' => __('القائمة الجانبية للمقال (السايدبار)', 'alba'),
        'type'      => 'checkbox'
    )
);

    
    $wp_customize->add_section('albathemecolor', array(
        'title' => __('الالوان', 'alba'),
        'panel' => 'albasporthemeoption',
        'priority'    => 8,
        'description' => '',
    ));

    // خلفية الموقع
    $wp_customize->add_setting('background_color', array(
        'default' => '#EEEEEE',
        'transport' => 'refresh',
    ));

    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'background_color', array(
        'section' => 'albathemecolor',
        'label' => esc_html__('خلفية الموقع', 'alba'),
    )));

    // main color
    $wp_customize->add_setting('header_bd', array(
        'default' => '#FFFFFF',
        'transport' => 'refresh',
    ));
    $wp_customize->add_setting('header_color', array(
        'default' => '#000000',
        'transport' => 'refresh',
    ));

    $wp_customize->add_setting('footer_bd', array(
        'default' => '#272727',
        'transport' => 'refresh',
    ));
    $wp_customize->add_setting('footer_color', array(
        'default' => '#c6c6c6',
        'transport' => 'refresh',
    ));

    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'header_bd', array(
        'section' => 'albathemecolor',
        'label' => esc_html__('خلفية الهيدر', 'alba'),
    )));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'header_color', 
    array(
        'section' => 'albathemecolor',
        'label' => esc_html__('الون الروابط في الهيدر', 'alba'),
    )));

    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'footer_bd', array(
        'section' => 'albathemecolor',
        'label' => esc_html__('خلفية الفوتر', 'alba'),
    )));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'footer_color', 
    array(
        'section' => 'albathemecolor',
        'label' => esc_html__('الون الروابط في الفوتر', 'alba'),
    )));

    
    // Add section.
    $wp_customize->add_section('AspThemeAds', array(
        'title' => __('اعلان اسفل الهيدر', 'alba'),
        'panel' => 'albasporthemeoption',
        'description' => __('إعلانات تظهر اسفل الهيدر واعلى الفوتر في كل صفحات الموقع', 'alba'),

        'priority' => 10,
    ));
    $wp_customize->add_section('AlbaFooterAds', array(
        'title' => __('اعلان اعلى الفوتر', 'alba'),
        'panel' => 'albasporthemeoption',
        'description' => __('إعلانات تظهر اسفل الهيدر واعلى الفوتر في كل صفحات الموقع', 'alba'),

        'priority' => 10,
    ));
    // Add setting
    $wp_customize->add_setting('AlbaHeaderAds', array(
        'default' => '<div style="background: #fcfcfc;color: #5d5d5d;height: 90px;width: 100%;border: 1px solid #e6ecf0;text-align: center;line-height: 90px;">
        مساحة اعلانية (ADS)
        </div>',
        'sanitize_callback' => 'wpforge_sanitize_text',
    ));
    $wp_customize->add_setting('AlbaFooterAds', array(
    'default' => '<div style="background: #fcfcfc;color: #5d5d5d;height: 90px;width: 100%;border: 1px solid #e6ecf0;text-align: center;line-height: 90px;">
    مساحة اعلانية (ADS)
    </div>',
        'sanitize_callback' => 'wpforge_sanitize_text',
    ));
    // Add control
    $wp_customize->add_control(new WP_Customize_Control(
        $wp_customize,
        'AspThemeAds',
        array(
            'label' => __('كود الاعلان', 'alba'),
            'section' => 'AspThemeAds',
            'settings' => 'AlbaHeaderAds',
            'type' => 'textarea',
        )
    )
    );
    $wp_customize->add_control(new WP_Customize_Control(
        $wp_customize,
        'AlbaFooterAds',
        array(
            'label' => __('كود الاعلان', 'alba'),
            'section' => 'AlbaFooterAds',
            'settings' => 'AlbaFooterAds',
            'type' => 'textarea',
        )
    )
    );
    // Sanitize text
    function sanitize_text($text)
    {
        return sanitize_text_field($text);
    }
    function wpforge_sanitize_text($input)
    {
        return wp_kses_post(force_balance_tags($input));
    }
}



function alba_customize_register_soc($wp_customize){


}


add_action('customize_register', 'alba_customize_register_soc');

function alba_theme_sanitize_checkbox($input) {
if ($input == 1) {
    return 1;
} else {
    return '';
}
}
/**
* Sanitize the settings with textareas
*/
function alba_theme_sanitize_text( $value ) {
return $value;
}

function AlbaSocial(){
if(get_theme_mod('albahsocial')):?>
    <ul id="hdsocial">
        <li class="facebook"><a href="<?php echo get_theme_mod('albafacebook');?>" target="_blank" title="facebook"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512"><path fill="currentColor" d="M279.14 288l14.22-92.66h-88.91v-60.13c0-25.35 12.42-50.06 52.24-50.06h40.42V6.26S260.43 0 225.36 0c-73.22 0-121.08 44.38-121.08 124.72v70.62H22.89V288h81.39v224h100.17V288z"/></svg></a></li>
        <li class="telegram"><a href="<?php echo get_theme_mod('albatelegram');?>" target="_blank" title="telegram"><svg role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 496 512"><path fill="currentColor" d="M248 8C111 8 0 119 0 256s111 248 248 248 248-111 248-248S385 8 248 8zm121.8 169.9l-40.7 191.8c-3 13.6-11.1 16.9-22.4 10.5l-62-45.7-29.9 28.8c-3.3 3.3-6.1 6.1-12.5 6.1l4.4-63.1 114.9-103.8c5-4.4-1.1-6.9-7.7-2.5l-142 89.4-61.2-19.1c-13.3-4.2-13.6-13.3 2.8-19.7l239.1-92.2c11.1-4 20.8 2.7 17.2 19.5z" class=""></path></svg></a></li>
        <li class="twitter"><a href="<?php echo get_theme_mod('albatwitter');?>" target="_blank" title="twitter"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path fill="currentColor" d="M459.37 151.716c.325 4.548.325 9.097.325 13.645 0 138.72-105.583 298.558-298.558 298.558-59.452 0-114.68-17.219-161.137-47.106 8.447.974 16.568 1.299 25.34 1.299 49.055 0 94.213-16.568 130.274-44.832-46.132-.975-84.792-31.188-98.112-72.772 6.498.974 12.995 1.624 19.818 1.624 9.421 0 18.843-1.3 27.614-3.573-48.081-9.747-84.143-51.98-84.143-102.985v-1.299c13.969 7.797 30.214 12.67 47.431 13.319-28.264-18.843-46.781-51.005-46.781-87.391 0-19.492 5.197-37.36 14.294-52.954 51.655 63.675 129.3 105.258 216.365 109.807-1.624-7.797-2.599-15.918-2.599-24.04 0-57.828 46.782-104.934 104.934-104.934 30.213 0 57.502 12.67 76.67 33.137 23.715-4.548 46.456-13.32 66.599-25.34-7.798 24.366-24.366 44.833-46.132 57.827 21.117-2.273 41.584-8.122 60.426-16.243-14.292 20.791-32.161 39.308-52.628 54.253z" class=""></path></svg></a></li>
        <li class="youtube"><a href="<?php echo get_theme_mod('albayotube');?>" target="_blank" title="youtube"><svg style="width: 20px;" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512"><path fill="currentColor" d="M549.655 124.083c-6.281-23.65-24.787-42.276-48.284-48.597C458.781 64 288 64 288 64S117.22 64 74.629 75.486c-23.497 6.322-42.003 24.947-48.284 48.597-11.412 42.867-11.412 132.305-11.412 132.305s0 89.438 11.412 132.305c6.281 23.65 24.787 41.5 48.284 47.821C117.22 448 288 448 288 448s170.78 0 213.371-11.486c23.497-6.321 42.003-24.171 48.284-47.821 11.412-42.867 11.412-132.305 11.412-132.305s0-89.438-11.412-132.305zm-317.51 213.508V175.185l142.739 81.205-142.739 81.201z"/></svg></a></li>
    </ul>
<?php endif;
}


