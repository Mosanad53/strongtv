<?php
   /**
   * Template Name: مباريات اليوم
   *
   * @package WordPress
   * @subpackage Twenty_Fourteen
   * @since Twenty Fourteen 1.0
   */
   
   get_header(); ?>
<?php echo do_shortcode('[AlbaSportTable]'); ?>
<?php if (have_posts()): ?>
<main id="main" class="AlbaSport-main box">
   <div class="box-title">
      <h2 class="title"><?php _e('اخر الاخبار','alba');?></h2>
   </div>
   <div class="polist row">
      <?php while (have_posts()): the_post();?>
      <article id="post-<?php the_ID();?>" class="post_outer col-sm-6 col-12 col-md-3">
         <a class="d-flex flex-column flex-grow post-link" href="<?php the_permalink()?>" title="<?php the_title();?>">
            <div class="inner-content">
               <div class="thumbnail">
                  <div class="thumb-wrap" style="background-image: url('<?php the_post_thumbnail_url('medium');?>');"></div>
               </div>
               <span class="overlay"></span>
               <h3 class="main-color-border">
                  <div class="title-inner">
                     <?php the_title();?>
                  </div>
               </h3>
            </div>
         </a>
      </article>
      <?php endwhile;?>
   </div>
   <?php if (function_exists("AlbaSport_pagination")) {AlbaSport_pagination();}?>
</main>
<?php endif;?>
<?php get_footer();
